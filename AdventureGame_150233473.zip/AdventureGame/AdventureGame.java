
//Main Method to run the game
public class AdventureGame {
    public static void main(String[] args) {
        Game g = new Game();
        g.makeCharacters();
        g.WelcomeMessage();
        g.level1();
    }
    
}
